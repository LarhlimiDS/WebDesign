import './globals.css';
import type { Metadata } from 'next';
import { Inter, Playfair_Display } from 'next/font/google';

const inter = Inter({ 
  subsets: ['latin'],
  variable: '--font-inter',
  display: 'swap',
});

const playfair = Playfair_Display({ 
  subsets: ['latin'],
  variable: '--font-playfair',
  display: 'swap',
});

export const metadata: Metadata = {
  title: 'Thérapie Holistique - Bien-être et Guérison Naturelle',
  description: 'Découvrez nos services de thérapie holistique : massothérapie, aromathérapie, réflexologie, méditation, yoga, coaching émotionnel, naturopathie et Reiki. Votre chemin vers le bien-être total.',
  keywords: 'thérapie holistique, massothérapie, aromathérapie, réflexologie, méditation, yoga, coaching émotionnel, naturopathie, reiki, bien-être, guérison naturelle',
  authors: [{ name: 'Centre de Thérapie Holistique' }],
  openGraph: {
    title: 'Thérapie Holistique - Bien-être et Guérison Naturelle',
    description: 'Découvrez nos services de thérapie holistique pour votre bien-être total',
    type: 'website',
    locale: 'fr_FR',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Thérapie Holistique - Bien-être et Guérison Naturelle',
    description: 'Découvrez nos services de thérapie holistique pour votre bien-être total',
  },
  viewport: 'width=device-width, initial-scale=1',
  robots: 'index, follow',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="fr" className={`${inter.variable} ${playfair.variable}`}>
      <head>
        <link rel="icon" href="/favicon.ico" />
        <meta name="theme-color" content="#22c55e" />
      </head>
      <body className={`${inter.className} antialiased`}>
        {children}
      </body>
    </html>
  );
}