'use client';

import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Star, Quote, Heart, CheckCircle } from 'lucide-react';
import { useState } from 'react';

const Testimonials = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  const [activeTestimonial, setActiveTestimonial] = useState(0);

  const testimonials = [
    {
      name: 'Marie Dubois',
      age: 34,
      service: 'Massothérapie & Aromathérapie',
      rating: 5,
      text: 'Une expérience transformatrice ! Après des mois de stress intense, j\'ai retrouvé mon équilibre grâce aux séances de massothérapie. L\'équipe est exceptionnelle et l\'approche holistique a vraiment fait la différence.',
      image: 'https://images.pexels.com/photos/3763188/pexels-photo-3763188.jpeg?auto=compress&cs=tinysrgb&w=150',
      results: ['Réduction du stress de 80%', 'Amélioration du sommeil', 'Regain d\'énergie']
    },
    {
      name: 'Pierre Martin',
      age: 42,
      service: 'Coaching Émotionnel & Méditation',
      rating: 5,
      text: 'Le coaching émotionnel m\'a aidé à traverser une période difficile de ma vie. Les techniques de méditation que j\'ai apprises continuent de m\'accompagner au quotidien. Je recommande vivement !',
      image: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=150',
      results: ['Meilleure gestion du stress', 'Confiance retrouvée', 'Clarté mentale']
    },
    {
      name: 'Sophie Laurent',
      age: 28,
      service: 'Yoga Thérapeutique & Naturopathie',
      rating: 5,
      text: 'Grâce au yoga thérapeutique et aux conseils en naturopathie, j\'ai complètement transformé ma relation à mon corps. Les douleurs chroniques ont disparu et je me sens plus énergique que jamais.',
      image: 'https://images.pexels.com/photos/3763188/pexels-photo-3763188.jpeg?auto=compress&cs=tinysrgb&w=150',
      results: ['Disparition des douleurs', 'Amélioration de la posture', 'Vitalité retrouvée']
    },
    {
      name: 'Jean-Luc Moreau',
      age: 55,
      service: 'Reiki & Réflexologie',
      rating: 5,
      text: 'Sceptique au début, je suis maintenant convaincu des bienfaits des thérapies énergétiques. Les séances de Reiki et de réflexologie m\'ont apporté une paix intérieure que je n\'avais jamais connue.',
      image: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=150',
      results: ['Équilibre énergétique', 'Réduction de l\'anxiété', 'Bien-être général']
    }
  ];

  const stats = [
    { number: '98%', label: 'Clients satisfaits' },
    { number: '4.9/5', label: 'Note moyenne' },
    { number: '500+', label: 'Témoignages' },
    { number: '95%', label: 'Recommandations' }
  ];

  return (
    <section id="temoignages" className="section-padding bg-gradient-to-br from-primary-50 to-secondary-50">
      <div className="container-custom">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 50 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={inView ? { opacity: 1, scale: 1 } : {}}
            transition={{ delay: 0.2, duration: 0.6 }}
            className="inline-flex items-center gap-2 bg-white rounded-full px-6 py-3 mb-6 shadow-sm"
          >
            <Heart className="w-5 h-5 text-primary-600" />
            <span className="text-primary-700 font-medium">Témoignages</span>
          </motion.div>

          <h2 className="text-4xl md:text-5xl font-serif font-bold text-gray-800 mb-6">
            Ils Ont Transformé{' '}
            <span className="text-gradient">Leur Vie</span>
          </h2>

          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Découvrez les histoires inspirantes de nos clients qui ont retrouvé 
            équilibre et bien-être grâce à nos thérapies holistiques.
          </p>
        </motion.div>

        {/* Stats */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.4, duration: 0.8 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-16"
        >
          {stats.map((stat, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={inView ? { opacity: 1, scale: 1 } : {}}
              transition={{ delay: 0.6 + index * 0.1, duration: 0.6 }}
              className="text-center bg-white rounded-xl p-6 shadow-sm"
            >
              <div className="text-3xl md:text-4xl font-bold text-primary-600 mb-2">
                {stat.number}
              </div>
              <div className="text-gray-600 text-sm uppercase tracking-wide">
                {stat.label}
              </div>
            </motion.div>
          ))}
        </motion.div>

        {/* Main testimonial */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.8, duration: 0.8 }}
          className="bg-white rounded-2xl shadow-xl p-8 md:p-12 mb-12"
        >
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Testimonial content */}
            <div>
              <div className="flex items-center gap-1 mb-6">
                {[...Array(testimonials[activeTestimonial].rating)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 text-accent-400 fill-current" />
                ))}
              </div>

              <Quote className="w-12 h-12 text-primary-200 mb-6" />

              <blockquote className="text-xl md:text-2xl text-gray-700 leading-relaxed mb-8 font-serif">
                "{testimonials[activeTestimonial].text}"
              </blockquote>

              <div className="flex items-center gap-4 mb-6">
                <img
                  src={testimonials[activeTestimonial].image}
                  alt={testimonials[activeTestimonial].name}
                  className="w-16 h-16 rounded-full object-cover"
                />
                <div>
                  <div className="font-semibold text-gray-800">
                    {testimonials[activeTestimonial].name}
                  </div>
                  <div className="text-gray-600 text-sm">
                    {testimonials[activeTestimonial].age} ans
                  </div>
                  <div className="text-primary-600 text-sm font-medium">
                    {testimonials[activeTestimonial].service}
                  </div>
                </div>
              </div>

              {/* Results */}
              <div className="space-y-3">
                <h4 className="font-semibold text-gray-800 mb-3">Résultats obtenus :</h4>
                {testimonials[activeTestimonial].results.map((result, index) => (
                  <div key={index} className="flex items-center gap-3">
                    <CheckCircle className="w-5 h-5 text-primary-600 flex-shrink-0" />
                    <span className="text-gray-700">{result}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Testimonial navigation */}
            <div className="space-y-4">
              {testimonials.map((testimonial, index) => (
                <motion.button
                  key={index}
                  onClick={() => setActiveTestimonial(index)}
                  className={`w-full text-left p-4 rounded-xl transition-all duration-300 ${
                    index === activeTestimonial
                      ? 'bg-primary-100 border-2 border-primary-300'
                      : 'bg-gray-50 hover:bg-gray-100 border-2 border-transparent'
                  }`}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <div className="flex items-center gap-3">
                    <img
                      src={testimonial.image}
                      alt={testimonial.name}
                      className="w-12 h-12 rounded-full object-cover"
                    />
                    <div className="flex-1">
                      <div className="font-medium text-gray-800">
                        {testimonial.name}
                      </div>
                      <div className="text-sm text-gray-600">
                        {testimonial.service}
                      </div>
                    </div>
                    <div className="flex items-center gap-1">
                      {[...Array(testimonial.rating)].map((_, i) => (
                        <Star key={i} className="w-3 h-3 text-accent-400 fill-current" />
                      ))}
                    </div>
                  </div>
                </motion.button>
              ))}
            </div>
          </div>
        </motion.div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 1, duration: 0.8 }}
          className="text-center"
        >
          <h3 className="text-2xl md:text-3xl font-serif font-bold text-gray-800 mb-4">
            Prêt(e) à commencer votre transformation ?
          </h3>
          <p className="text-gray-600 mb-8 max-w-2xl mx-auto">
            Rejoignez des centaines de personnes qui ont déjà transformé leur vie 
            grâce à nos thérapies holistiques.
          </p>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="btn-primary"
          >
            Commencer mon parcours
          </motion.button>
        </motion.div>
      </div>
    </section>
  );
};

export default Testimonials;