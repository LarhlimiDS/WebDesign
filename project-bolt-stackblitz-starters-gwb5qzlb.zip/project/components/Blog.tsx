'use client';

import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Calendar, User, ArrowRight, BookOpen, Clock, Tag } from 'lucide-react';

const Blog = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  const articles = [
    {
      id: 1,
      title: 'Les Bienfaits de la Méditation sur le Stress Chronique',
      excerpt: 'Découvrez comment la méditation peut transformer votre relation au stress et améliorer votre qualité de vie au quotidien.',
      author: 'Dr. Marie Dubois',
      date: '15 Mars 2024',
      readTime: '5 min',
      category: 'Méditation',
      image: 'https://images.pexels.com/photos/3822622/pexels-photo-3822622.jpeg?auto=compress&cs=tinysrgb&w=600',
      featured: true
    },
    {
      id: 2,
      title: 'Aromathérapie : Guide Complet des Huiles Essentielles',
      excerpt: 'Un guide pratique pour comprendre et utiliser les huiles essentielles dans votre routine bien-être.',
      author: 'Sophie Laurent',
      date: '12 Mars 2024',
      readTime: '8 min',
      category: 'Aromathérapie',
      image: 'https://images.pexels.com/photos/4041392/pexels-photo-4041392.jpeg?auto=compress&cs=tinysrgb&w=600'
    },
    {
      id: 3,
      title: 'Yoga Thérapeutique : Soulager les Douleurs Dorsales',
      excerpt: 'Des postures spécifiques et des techniques respiratoires pour prévenir et soulager les maux de dos.',
      author: 'Pierre Martin',
      date: '10 Mars 2024',
      readTime: '6 min',
      category: 'Yoga',
      image: 'https://images.pexels.com/photos/3822622/pexels-photo-3822622.jpeg?auto=compress&cs=tinysrgb&w=600'
    },
    {
      id: 4,
      title: 'Naturopathie : Renforcer son Immunité Naturellement',
      excerpt: 'Conseils pratiques et remèdes naturels pour booster votre système immunitaire de façon durable.',
      author: 'Dr. Jean Moreau',
      date: '8 Mars 2024',
      readTime: '7 min',
      category: 'Naturopathie',
      image: 'https://images.pexels.com/photos/4041392/pexels-photo-4041392.jpeg?auto=compress&cs=tinysrgb&w=600'
    },
    {
      id: 5,
      title: 'Reiki : Comprendre l\'Énergie Universelle',
      excerpt: 'Introduction aux principes fondamentaux du Reiki et à ses applications thérapeutiques.',
      author: 'Marie Dubois',
      date: '5 Mars 2024',
      readTime: '4 min',
      category: 'Reiki',
      image: 'https://images.pexels.com/photos/3757942/pexels-photo-3757942.jpeg?auto=compress&cs=tinysrgb&w=600'
    },
    {
      id: 6,
      title: 'Réflexologie : Cartographie des Points de Pression',
      excerpt: 'Apprenez à localiser et stimuler les points réflexes pour améliorer votre bien-être général.',
      author: 'Sophie Laurent',
      date: '3 Mars 2024',
      readTime: '6 min',
      category: 'Réflexologie',
      image: 'https://images.pexels.com/photos/6663461/pexels-photo-6663461.jpeg?auto=compress&cs=tinysrgb&w=600'
    }
  ];

  const categories = ['Tous', 'Méditation', 'Aromathérapie', 'Yoga', 'Naturopathie', 'Reiki', 'Réflexologie'];

  return (
    <section id="blog" className="section-padding bg-white">
      <div className="container-custom">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 50 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={inView ? { opacity: 1, scale: 1 } : {}}
            transition={{ delay: 0.2, duration: 0.6 }}
            className="inline-flex items-center gap-2 bg-primary-100 rounded-full px-6 py-3 mb-6"
          >
            <BookOpen className="w-5 h-5 text-primary-600" />
            <span className="text-primary-700 font-medium">Blog & Ressources</span>
          </motion.div>

          <h2 className="text-4xl md:text-5xl font-serif font-bold text-gray-800 mb-6">
            Conseils &{' '}
            <span className="text-gradient">Expertise</span>
          </h2>

          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Découvrez nos articles, guides pratiques et conseils d'experts pour 
            approfondir vos connaissances en thérapies holistiques.
          </p>
        </motion.div>

        {/* Categories filter */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.4, duration: 0.8 }}
          className="flex flex-wrap justify-center gap-4 mb-12"
        >
          {categories.map((category, index) => (
            <motion.button
              key={category}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={inView ? { opacity: 1, scale: 1 } : {}}
              transition={{ delay: 0.6 + index * 0.1, duration: 0.6 }}
              className={`px-6 py-3 rounded-full font-medium transition-all duration-300 ${
                index === 0
                  ? 'bg-primary-600 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-primary-100 hover:text-primary-700'
              }`}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              {category}
            </motion.button>
          ))}
        </motion.div>

        {/* Featured article */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.8, duration: 0.8 }}
          className="mb-16"
        >
          <div className="bg-gradient-to-r from-primary-600 to-secondary-600 rounded-2xl overflow-hidden shadow-2xl">
            <div className="grid lg:grid-cols-2 items-center">
              <div className="p-8 md:p-12 text-white">
                <div className="inline-flex items-center gap-2 bg-white/20 rounded-full px-4 py-2 mb-6">
                  <Tag className="w-4 h-4" />
                  <span className="text-sm font-medium">Article en vedette</span>
                </div>
                
                <h3 className="text-3xl md:text-4xl font-serif font-bold mb-4">
                  {articles[0].title}
                </h3>
                
                <p className="text-primary-100 mb-6 leading-relaxed">
                  {articles[0].excerpt}
                </p>
                
                <div className="flex items-center gap-6 mb-8 text-sm text-primary-200">
                  <div className="flex items-center gap-2">
                    <User className="w-4 h-4" />
                    <span>{articles[0].author}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4" />
                    <span>{articles[0].date}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4" />
                    <span>{articles[0].readTime}</span>
                  </div>
                </div>
                
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="btn-outline group"
                >
                  Lire l'article
                  <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
                </motion.button>
              </div>
              
              <div className="h-64 lg:h-full">
                <img
                  src={articles[0].image}
                  alt={articles[0].title}
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
          </div>
        </motion.div>

        {/* Articles grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {articles.slice(1).map((article, index) => (
            <motion.article
              key={article.id}
              initial={{ opacity: 0, y: 30 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: 1 + index * 0.1, duration: 0.6 }}
              className="bg-white rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden group border border-gray-100"
            >
              <div className="relative h-48 overflow-hidden">
                <img
                  src={article.image}
                  alt={article.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute top-4 left-4">
                  <span className="bg-primary-600 text-white px-3 py-1 rounded-full text-xs font-medium">
                    {article.category}
                  </span>
                </div>
              </div>
              
              <div className="p-6">
                <h3 className="text-xl font-semibold text-gray-800 mb-3 group-hover:text-primary-600 transition-colors line-clamp-2">
                  {article.title}
                </h3>
                
                <p className="text-gray-600 mb-4 leading-relaxed line-clamp-3">
                  {article.excerpt}
                </p>
                
                <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
                  <div className="flex items-center gap-2">
                    <User className="w-4 h-4" />
                    <span>{article.author}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4" />
                    <span>{article.readTime}</span>
                  </div>
                </div>
                
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-500">{article.date}</span>
                  <motion.button
                    whileHover={{ x: 5 }}
                    className="text-primary-600 hover:text-primary-700 font-medium text-sm flex items-center gap-1"
                  >
                    Lire plus
                    <ArrowRight className="w-4 h-4" />
                  </motion.button>
                </div>
              </div>
            </motion.article>
          ))}
        </div>

        {/* Newsletter signup */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 1.4, duration: 0.8 }}
          className="mt-16 bg-gradient-to-r from-sage-100 to-primary-100 rounded-2xl p-8 md:p-12 text-center"
        >
          <h3 className="text-2xl md:text-3xl font-serif font-bold text-gray-800 mb-4">
            Restez informé(e) de nos derniers articles
          </h3>
          <p className="text-gray-600 mb-8 max-w-2xl mx-auto">
            Recevez chaque semaine nos conseils d'experts, guides pratiques et 
            dernières découvertes en thérapies holistiques.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
            <input
              type="email"
              placeholder="Votre adresse email"
              className="flex-1 px-6 py-4 rounded-full border border-gray-300 focus:border-primary-500 focus:outline-none focus:ring-2 focus:ring-primary-200"
            />
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="btn-primary whitespace-nowrap"
            >
              S'abonner
            </motion.button>
          </div>
          
          <p className="text-sm text-gray-500 mt-4">
            Pas de spam, désabonnement possible à tout moment.
          </p>
        </motion.div>
      </div>
    </section>
  );
};

export default Blog;