'use client';

import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { 
  Flower2, 
  Waves, 
  Footprints, 
  Brain, 
  Dumbbell, 
  Heart, 
  Leaf, 
  Sparkles,
  Clock,
  Star,
  ArrowRight
} from 'lucide-react';

const Services = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  const services = [
    {
      icon: Waves,
      title: 'Massothérapie',
      description: 'Techniques de massage thérapeutique pour libérer les tensions et restaurer l\'équilibre corporel.',
      duration: '60-90 min',
      price: 'À partir de 80€',
      benefits: ['Réduction du stress', 'Amélioration circulation', 'Détente musculaire'],
      image: 'https://images.pexels.com/photos/3757942/pexels-photo-3757942.jpeg?auto=compress&cs=tinysrgb&w=600'
    },
    {
      icon: Flower2,
      title: 'Aromathérapie',
      description: 'Utilisation d\'huiles essentielles pures pour harmoniser corps et esprit.',
      duration: '45-60 min',
      price: 'À partir de 65€',
      benefits: ['Équilibre émotionnel', 'Purification énergétique', 'Relaxation profonde'],
      image: 'https://images.pexels.com/photos/4041392/pexels-photo-4041392.jpeg?auto=compress&cs=tinysrgb&w=600'
    },
    {
      icon: Footprints,
      title: 'Réflexologie',
      description: 'Stimulation des points réflexes pour activer les capacités d\'auto-guérison.',
      duration: '50 min',
      price: 'À partir de 70€',
      benefits: ['Amélioration circulation', 'Réduction tensions', 'Équilibre énergétique'],
      image: 'https://images.pexels.com/photos/6663461/pexels-photo-6663461.jpeg?auto=compress&cs=tinysrgb&w=600'
    },
    {
      icon: Brain,
      title: 'Méditation Guidée',
      description: 'Séances de méditation pour développer la pleine conscience et la sérénité.',
      duration: '30-45 min',
      price: 'À partir de 45€',
      benefits: ['Réduction stress', 'Clarté mentale', 'Paix intérieure'],
      image: 'https://images.pexels.com/photos/3822622/pexels-photo-3822622.jpeg?auto=compress&cs=tinysrgb&w=600'
    },
    {
      icon: Dumbbell,
      title: 'Yoga Thérapeutique',
      description: 'Pratique adaptée du yoga pour renforcer le corps et apaiser l\'esprit.',
      duration: '60-75 min',
      price: 'À partir de 55€',
      benefits: ['Flexibilité', 'Force intérieure', 'Équilibre postural'],
      image: 'https://images.pexels.com/photos/3822622/pexels-photo-3822622.jpeg?auto=compress&cs=tinysrgb&w=600'
    },
    {
      icon: Heart,
      title: 'Coaching Émotionnel',
      description: 'Accompagnement personnalisé pour gérer les émotions et développer la résilience.',
      duration: '60 min',
      price: 'À partir de 90€',
      benefits: ['Gestion émotions', 'Confiance en soi', 'Développement personnel'],
      image: 'https://images.pexels.com/photos/7176026/pexels-photo-7176026.jpeg?auto=compress&cs=tinysrgb&w=600'
    },
    {
      icon: Leaf,
      title: 'Naturopathie',
      description: 'Conseils en hygiène de vie et remèdes naturels pour optimiser votre santé.',
      duration: '75 min',
      price: 'À partir de 85€',
      benefits: ['Vitalité naturelle', 'Prévention santé', 'Équilibre nutritionnel'],
      image: 'https://images.pexels.com/photos/4041392/pexels-photo-4041392.jpeg?auto=compress&cs=tinysrgb&w=600'
    },
    {
      icon: Sparkles,
      title: 'Reiki',
      description: 'Transmission d\'énergie universelle pour rééquilibrer vos centres énergétiques.',
      duration: '60 min',
      price: 'À partir de 75€',
      benefits: ['Rééquilibrage énergétique', 'Guérison holistique', 'Harmonie intérieure'],
      image: 'https://images.pexels.com/photos/3757942/pexels-photo-3757942.jpeg?auto=compress&cs=tinysrgb&w=600'
    }
  ];

  return (
    <section id="services" className="section-padding bg-white">
      <div className="container-custom">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 50 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={inView ? { opacity: 1, scale: 1 } : {}}
            transition={{ delay: 0.2, duration: 0.6 }}
            className="inline-flex items-center gap-2 bg-primary-100 rounded-full px-6 py-3 mb-6"
          >
            <Sparkles className="w-5 h-5 text-primary-600" />
            <span className="text-primary-700 font-medium">Nos Services</span>
          </motion.div>

          <h2 className="text-4xl md:text-5xl font-serif font-bold text-gray-800 mb-6">
            Thérapies{' '}
            <span className="text-gradient">Holistiques</span>
          </h2>

          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Découvrez notre gamme complète de thérapies naturelles, chacune conçue pour 
            harmoniser votre corps, votre esprit et votre âme.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: 0.4 + index * 0.1, duration: 0.6 }}
              className="group bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 overflow-hidden border border-gray-100 hover:border-primary-200"
            >
              {/* Image */}
              <div className="relative h-48 overflow-hidden">
                <img
                  src={service.image}
                  alt={service.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
                <div className="absolute top-4 left-4 w-12 h-12 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center">
                  <service.icon className="w-6 h-6 text-primary-600" />
                </div>
              </div>

              {/* Content */}
              <div className="p-6">
                <h3 className="text-xl font-semibold text-gray-800 mb-3 group-hover:text-primary-600 transition-colors">
                  {service.title}
                </h3>
                
                <p className="text-gray-600 text-sm mb-4 leading-relaxed">
                  {service.description}
                </p>

                {/* Duration and Price */}
                <div className="flex items-center justify-between mb-4 text-sm">
                  <div className="flex items-center gap-1 text-gray-500">
                    <Clock className="w-4 h-4" />
                    <span>{service.duration}</span>
                  </div>
                  <div className="font-semibold text-primary-600">
                    {service.price}
                  </div>
                </div>

                {/* Benefits */}
                <div className="space-y-2 mb-6">
                  {service.benefits.map((benefit, benefitIndex) => (
                    <div key={benefitIndex} className="flex items-center gap-2 text-sm text-gray-600">
                      <Star className="w-3 h-3 text-accent-500 flex-shrink-0" />
                      <span>{benefit}</span>
                    </div>
                  ))}
                </div>

                {/* CTA Button */}
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="w-full bg-primary-600 hover:bg-primary-700 text-white py-3 px-4 rounded-lg font-medium transition-colors duration-300 flex items-center justify-center gap-2 group"
                >
                  Réserver
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </motion.button>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Call to action */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 1.2, duration: 0.8 }}
          className="text-center mt-16"
        >
          <div className="bg-gradient-to-r from-primary-50 to-secondary-50 rounded-2xl p-8 md:p-12">
            <h3 className="text-2xl md:text-3xl font-serif font-bold text-gray-800 mb-4">
              Pas sûr(e) de quel service choisir ?
            </h3>
            <p className="text-gray-600 mb-6 max-w-2xl mx-auto">
              Nos thérapeutes expérimentés vous aideront à identifier les thérapies 
              les mieux adaptées à vos besoins spécifiques.
            </p>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="btn-primary"
            >
              Consultation gratuite
            </motion.button>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default Services;